---
name: Executive Light Tech
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: 4rem
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 2rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: '0'
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: '0'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-xs:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies an executive enterprise technology aesthetic: razor-sharp, ultra-clean, and authoritative. Designed for modern executives, technical leaders, and operators who demand high-density clarity without visual fatigue, the system projects institutional precision and quiet confidence.

The visual direction draws from modern high-performance interfaces—merging structural clarity, deliberate whitespace, and disciplined micro-interactions. Surfaces remain crisp and light, punctuated by calculated strokes and an electric royal blue accent that immediately signals action and critical path data. Visual clutter is eliminated in favor of typographic contrast, semantic hierarchy, and architectural alignment.

## Colors

The palette establishes an ultra-clean, high-legibility foundation using a layered neutral system paired with high-voltage accents:

- **Primary (`#2563EB`)**: Royal electric blue engineered for primary CTAs, active operational indicators, and focus states. High-contrast white (`#FFFFFF`) is used for `on-primary`.
- **Primary Container (`#EFF6FF`)**: A soft blue wash for selected navigation nodes, badges, and contextual alerts.
- **Secondary / Accent Cyan (`#0284C7`)**: Specialized for telemetry metrics, sub-status highlights, and data visualization anchors.
- **Neutral Hierarchy**:
  - `surface` & `surface-bright`: `#FFFFFF` for pristine canvas foundations and base card containers.
  - `surface-dim`: `#F8FAFC` for page backgrounds and canvas-level structuring.
  - `surface-container-low`: `#F1F5F9` for secondary modular wells, code frames, and table headers.
  - `surface-container`: `#E2E8F0` for neutral fills and divider planes.
  - `on-surface`: `#0F172A` (deep slate navy) for unambiguous headline authority.
  - `on-surface-variant`: `#475569` (slate) for secondary metrics, labels, and helper copy.
  - `outline / border`: `#E2E8F0` applied consistently to create razor-thin divisions between content surfaces.

## Typography

The typographic hierarchy is built on **Plus Jakarta Sans**, offering geometric clarity combined with humanist terminal cuts that maintain warmth at enterprise scale.

- **Display & Large Headlines**: Set with negative tracking (`-0.02em` to `-0.03em`) and heavy weights (`700`–`800`) to anchor dashboard modules and hero metrics with immediate visual authority.
- **Body Text**: Tuned for high-density legibility. Standard body rests at `0.875rem` (14px) with a comfortable 22px line height, pairing naturally with complex tabular data and enterprise workflows.
- **Labels & Microcopy**: Compact sizes (`0.75rem` and `0.6875rem`) use uppercase or medium/bold weights with positive letter tracking to maximize scan speed in status badges, table headers, and metadata tags.

## Layout & Spacing

The layout philosophy uses a disciplined **12-column fluid grid** grounded by an absolute 8pt (0.5rem) spatial scale.

- **Desktop (1024px+)**: 12-column layout with `2rem` page margins and `1.5rem` gutters. Maximum application container cap is `1440px`, centering content with balanced horizontal gutters on wide displays.
- **Tablet (768px – 1023px)**: 8-column layout with `1.5rem` outer margins and `1rem` gutters. Sidebars fold into an off-canvas drawer or top executive toolbar.
- **Mobile (0 – 767px)**: 4-column layout with `1rem` outer margins and `1rem` gutters. Multi-column metric groups collapse into vertically stacked cards.
- **Component Layout Rhythm**: Component internals adhere to `0.25rem` (4px) micro-increments, utilizing `space-sm` (8px) for badge and icon spacing, `space-md` (16px) for interior card pads, and `space-xl` (32px) for section separation.

## Elevation & Depth

Visual hierarchy is maintained through **crisp low-contrast outlines** paired with **subtle ambient shadows**, avoiding heavy skeuomorphic drop shadows.

- **Level 0 (Flat / Canvas)**: Sits on `#F8FAFC` (surface-dim) with zero shadow and no outline.
- **Level 1 (Card / Container)**: Pure white `#FFFFFF` surface bordered by a 1px solid `#E2E8F0` stroke. Shadow is minimal: `0 1px 2px 0 rgba(15, 23, 42, 0.04)`.
- **Level 2 (Hover / Interactive Lift)**: Card elements on hover elevate slightly using a dual shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`, with border tinting to `#CBD5E1`.
- **Level 3 (Dropdown / Popover / Command Menu)**: `#FFFFFF` background with `0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.03)` and a crisp 1px `#E2E8F0` structural frame.
- **Level 4 (Modal / Critical Dialog)**: Grounded above an overlaid veil of `rgba(15, 23, 42, 0.4)` (with backdrop blur of `4px`), using a diffused `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

## Shapes

The design system employs a **Soft (`1`)** shape geometry. Buttons, inputs, and minor controls feature a precise `0.25rem` (4px) radius. Mid-tier cards, modals, and panel modules scale to `0.5rem` (8px), while outer display dialogs max out at `0.75rem` (12px). 

This restrained corner rounding avoids the toy-like softness of pill radii while bypassing the harshness of zero-radius brutalism, reinforcing modern corporate engineering rigor.

## Components

### Buttons
- **Primary**: Solid `#2563EB` background, `#FFFFFF` text, `0.25rem` radius, `font-weight: 600`. Hover shifts to `#1D4ED8`. Focus applies a 2px offset ring in `#2563EB`.
- **Secondary / Outline**: White `#FFFFFF` background, 1px `#E2E8F0` stroke, `#0F172A` text. Hover shifts background to `#F8FAFC` and stroke to `#CBD5E1`.
- **Ghost**: Transparent background, `#475569` text. Hover shifts background to `#F1F5F9` and text to `#0F172A`.

### Inputs & Form Fields
- Set against `#FFFFFF` with a 1px `#E2E8F0` border and `0.25rem` radius. Padding: `0.5rem 0.75rem`. Text: `#0F172A` (`body-md`), placeholder in `#94A3B8`.
- Focus state instantly triggers a crisp `border-color: #2563EB` and a box-shadow halo of `0 0 0 3px rgba(37, 99, 235, 0.12)`.

### Cards & Modular Containers
- Structured on `#FFFFFF` surfaces with a 1px border (`#E2E8F0`) and `0.5rem` radius. Header bands use `#F8FAFC` dividers when separating table headers or executive control summaries.

### Chips & Badges
- **Status Pills**: Compact `0.25rem` radius, uppercase tracking (`label-xs`).
- **Primary Badge**: `#EFF6FF` background with `#2563EB` text and a subtle 1px border of `rgba(37, 99, 235, 0.2)`.
- **Neutral Badge**: `#F1F5F9` background, `#475569` text, `#E2E8F0` border.

### Checkboxes & Radios
- Box width/height of 16px with a `0.25rem` radius (rounded-full for radios). Unchecked: `#FFFFFF` fill with a 1.5px `#CBD5E1` border. Checked: `#2563EB` fill with an ultra-crisp white tick vector.

### Data Tables
- Row lines bordered with 1px `#E2E8F0`. Header rows set on `#F8FAFC` using `label-md` in `#475569`. Alternating zebra rows are disabled; selection state renders as a subtle `#EFF6FF` wash.