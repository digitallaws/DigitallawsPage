---
name: Executive Dark Tech
colors:
  surface: '#071326'
  surface-dim: '#071326'
  surface-bright: '#2e394e'
  surface-container-lowest: '#030e21'
  surface-container-low: '#101c2f'
  surface-container: '#142033'
  surface-container-high: '#1f2a3e'
  surface-container-highest: '#2a3549'
  on-surface: '#d7e3fd'
  on-surface-variant: '#c3c6d7'
  inverse-surface: '#d7e3fd'
  inverse-on-surface: '#253145'
  outline: '#8d90a0'
  outline-variant: '#434655'
  surface-tint: '#b4c5ff'
  primary: '#b4c5ff'
  on-primary: '#002a78'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#0053db'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#b7c8e1'
  on-tertiary: '#213145'
  tertiary-container: '#5e6e85'
  on-tertiary-container: '#e9f0ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#071326'
  on-background: '#d7e3fd'
  surface-variant: '#2a3549'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-badge:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-ui:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system targets enterprise decision-makers, engineering leads, and technology executives. It reflects institutional stability, infrastructure-grade reliability, and state-of-the-art computational velocity. Drawing visual rigor from industry benchmarks like Stripe, Linear, Vercel, and Cloudflare, the design balances architectural precision with high-density utility.

The aesthetic fuses modern dark-mode minimalism with structural glassmorphism:
- **Surface Depth:** Immersive midnight canvases framed by deep dark blue structural containers.
- **Luminosity:** Controlled neon-inspired linear gradients (electric cobalt to sky cyan) used sparingly for telemetry indicators, interactive nodes, and system connectivity lines.
- **Precision Detailing:** 1px hairline translucent borders, monospaced metadata badges, crisp iconography, and high-legibility typographic hierarchies.

## Colors

The system uses a calibrated palette optimized for high-contrast dark environments, avoiding pure blacks in favor of deep atmospheric midnight tones.

- **Primary (`#2563EB`):** High-energy electric blue designated for core interactive triggers, dominant actions, selected node states, and focused navigation targets.
- **Secondary (`#38BDF8`):** Sky cyan highlighting active live streams, network pulses, gradient terminus points, and architectural data routes.
- **Tertiary (`#64748B`):** Muted slate gray reserved for secondary descriptions, inactive node borders, structural grid dividers, and secondary iconography.
- **Neutral Canvas (`#071326`):** Midnight Navy foundation underpinning the entire viewport.
- **Container Fill (`#0B192C`):** Deep Dark Blue used for surface cards, modals, navigation bars, and grouped panels.
- **Text Emphases:** Pure White (`#FFFFFF`) for primary titles and active metrics; Slate Light (`#94A3B8`) for body prose and system subtitles.

## Typography

The type scale balances editorial impact and system density through a two-font pairing:
- **Headings (Plus Jakarta Sans):** Geometric clarity and contemporary cuts project authoritative technological prowess. Letter tracking is tightened across larger displays to produce unified, high-impact titles.
- **Body & Controls (Inter):** Highly legible vertical metrics engineered for micro-copy, data tables, parameter readouts, and developer documentation.
- **System Tags & Badges:** `label-badge` utilizes uppercase transformation alongside wide letter spacing (`0.08em`) to anchor technical tags (e.g., `ECOSYSTEM`, `STABLE`, `API V2`).

## Layout & Spacing

A structured 12-column responsive fluid grid governs desktop displays, reducing to 6 columns on tablets and 4 columns on mobile devices.

- **Breakpoints:**
  - `Mobile:` 320px – 767px (`margin-mobile: 1.25rem`, `gutter-sm: 1rem`).
  - `Tablet:` 768px – 1023px (`margin: 2rem`, `gutter: 1.25rem`).
  - `Desktop:` 1024px – 1440px (`margin: 3rem`, `gutter: 1.5rem`).
  - `Max Content Bound:` 1280px centered constraint for executive dashboards and product landing flows.

Layout density is designed for both complex dashboards and streamlined presentations. Internal component paddings rely on `space-md` (1rem) for basic cards and `space-lg` (1.5rem) for high-level feature modules.

## Elevation & Depth

Visual hierarchy is constructed through luminosity tiers, selective backdrop filters, and subtle ambient glows rather than heavy drop shadows:

1. **Canvas Layer (Base):** Solid `#071326` background, occasionally textured with a radial cyan/blue ambient backlight (`radial-gradient(ellipse at 50% 0%, rgba(37, 99, 235, 0.15) 0%, transparent 70%)`).
2. **Surface Container:** `#0B192C` at 80% opacity overlaid with `backdrop-filter: blur(12px)`. Outlined with a fine 1px border (`rgba(255, 255, 255, 0.08)` or `rgba(56, 189, 248, 0.15)` on hover).
3. **Elevated Overlays & Flyouts:** Deep blue fill (`#0E223D`) with a dual-stage glow: an inner highlight of `inset 0 1px 0 rgba(255, 255, 255, 0.1)` and an outer shadow `0 16px 32px -8px rgba(0, 0, 0, 0.5)`.
4. **Interactive Focus:** Active nodes and focused inputs project a localized cyan glow (`0 0 16px rgba(56, 189, 248, 0.25)`).

## Shapes

The design system employs a refined radius scale (`roundedness: 2` base) to project engineering rigor without harsh brutalist corners:

- **Base Radius (0.5rem / 8px):** Applied to form inputs, dropdown selectors, standard buttons, code blocks, and nested list items.
- **Large Radius (1rem / 16px):** Applied to glassmorphic product cards, architecture ecosystem modules, modal panels, and feature previews.
- **Extra Large Radius (1.5rem / 24px):** Reserved for hero display panels and outer application layout containers.
- **Pill Badges (9999px):** Status badges, architecture node pills, and category markers (e.g., `ECOSYSTEM`) leverage fully rounded pill boundaries.

## Components

### Buttons
- **Primary:** Background of gradient `linear-gradient(135deg, #2563EB 0%, #1D4ED8 100%)`, text `#FFFFFF`, 1px border `rgba(255, 255, 255, 0.16)`. On hover: subtle scale elevation, top border highlight, and outer glow `0 0 20px rgba(37, 99, 235, 0.4)`.
- **Secondary / Ghost:** Semi-transparent background `rgba(255, 255, 255, 0.04)`, 1px border `rgba(255, 255, 255, 0.1)`, text `#FFFFFF`. Hover updates border to `rgba(56, 189, 248, 0.4)`.

### Badges & Chips
- **Technical Pill Badge:** Background `rgba(37, 99, 235, 0.15)`, text `#38BDF8`, 1px border `rgba(56, 189, 248, 0.3)`. Uses `label-badge` typography, with a 6px pulsing cyan LED dot for live environments.

### Cards & Architecture Nodes
- **Ecosystem Card:** Fill `#0B192C` (translucent at 85%), 1px perimeter border `rgba(255, 255, 255, 0.07)`, padding `1.25rem`. Title set in `Plus Jakarta Sans` semi-bold (`#FFFFFF`), description in `Inter` (`#64748B`). 
- **Connector Nodes:** Architectural links use 1px solid or dashed vector paths in `#2563EB` with center junction icons framed by glowing circular glyphs.

### Input Fields
- Dark canvas fill `rgba(7, 19, 38, 0.6)`, 1px border `rgba(100, 116, 139, 0.3)`, text `#FFFFFF`, placeholder `#64748B`. Focus state activates a sharp 1px border in `#38BDF8` with a 2px outer cyan ring blur.

### Checkboxes & Radios
- Square / rounded-circular containers using `#071326` background, 1px border `#64748B`. Selected state fills with `#2563EB` bearing a crisp `#FFFFFF` checkmark or center pip.